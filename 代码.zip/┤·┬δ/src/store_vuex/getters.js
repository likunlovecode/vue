export default{
    bFoot:(state)=>{return state.bFoot},
    bNav:(state)=>{return state.bNav},
    bLoading:(state)=>{return state.bLoading},
    home:(state)=>{return state.home}
  }