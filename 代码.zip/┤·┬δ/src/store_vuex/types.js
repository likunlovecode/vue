export const SHOW_NAV="SHOW_NAV";
export const HIDE_NAV="HIDE_NAV";
export const HIDE_FOOT="HIDE_FOOT";
export const SHOW_FOOT="SHOW_FOOT";
export const SHOW_LOADING="SHOW_LOADING";
export const HIDE_LOADING="HIDE_LOADING";
export const UPDATE_HOME="UPDATE_HOME";