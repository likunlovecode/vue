export default{
    bNav:true,
    bFoot:true,
    bLoading:false,
    home:[]
  }