<template>
  <div class="content">
     <h1 class="logo"><a href="index.html"><img src="../assets/images/logo.png" /></a></h1>
     
     <h2 class="title3">养生专家</h2>
     <ul class="new width100">
      <li><a href="newinfo.html">小贝壳素材有限公计有限公计有限公司始建于九十年代</a><span>2015年4月30日</span></li>
      <li><a href="newinfo.html">公司联手各大品牌材料厂商，推出“一站式采购”、“一条龙服务”理念</a><span>2015年4月30日</span></li>
      <li><a href="newinfo.html">时代的日益变迁，创造了信念不断进取的精神，制定出一系列的保障计划</a><span>2015年4月30日</span></li>
      <li><a href="newinfo.html">小贝壳素材有限公计有限公计有限公司始建于九十年代</a><span>2015年4月30日</span></li>
      <li><a href="newinfo.html">公司联手各大品牌材料厂商，推出“一站式采购”、“一条龙服务”理念</a><span>2015年4月30日</span></li>
      <li><a href="newinfo.html">时代的日益变迁，创造了信念不断进取的精神，制定出一系列的保障计划</a><span>2015年4月30日</span></li>
      <li><a href="newinfo.html">小贝壳素材有限公计有限公计有限公司始建于九十年代</a><span>2015年4月30日</span></li>
      <li><a href="newinfo.html">公司联手各大品牌材料厂商，推出“一站式采购”、“一条龙服务”理念</a><span>2015年4月30日</span></li>
      <li><a href="newinfo.html">时代的日益变迁，创造了信念不断进取的精神，制定出一系列的保障计划</a><span>2015年4月30日</span></li>
      <li><a href="newinfo.html">小贝壳素材有限公计有限公计有限公司始建于九十年代</a><span>2015年4月30日</span></li>
      <li><a href="newinfo.html">公司联手各大品牌材料厂商，推出“一站式采购”、“一条龙服务”理念</a><span>2015年4月30日</span></li>
      <li><a href="newinfo.html">时代的日益变迁，创造了信念不断进取的精神，制定出一系列的保障计划</a><span>2015年4月30日</span></li>
     </ul><!--new/-->
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
