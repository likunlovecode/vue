<template>
  <div class="content">
     <h1 class="logo"><a href="index.html"><img src="../assets/images/logo.png" /></a></h1>
     
     <h2 class="title3">我的农场</h2>
     <div class="Article">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;上海秦王网络科技有限公司经过多年的发展，秦王网络科技有限公司已成为一家专业的互联网应用技术及网络传播服务提供商，致力为用户提供成熟的互联网应用技术与专业的网络传播服务。<br /><br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;上海秦王网络科技有限公司凭借着对互联网行业的独到见解和丰富经验，在项目策划、项目管理、设计制作、技术开发和网络传播等多方面寻求平衡；在项目过程中，秦王网络通过周密的策划、深入的调查、理性的分析、精妙的创意、专业的实施，并同客户的实际情况和具体需求进行良好结合，为不同类型的客户提供最佳的互联网应用定制解决方案，帮助客户在新的全球化互联网环境中保持优势。<br /><br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;秦王网络秉承先进的互联网应用技术和领先的网络传播理念，建立了科学的管理机制和强有力的服务体系；专业资深的互联网应用技术服务团队将以最优化的资源配置与最佳的网络传播方式为源动力，为秦王网络庞大而优秀的客户群体打造网络新形象，正是秦王网络的独到之处。
     </div><!--Article/-->
    </div>
</template>

<script>
export default {

}
</script>

<style>
.title3{
	margin:20px 0 5px 0;
	height:30px;
	line-height:30px;
	padding:0 10px;
	color:#fff;
	background:#00B150;
	font-size:1.4rem;
	}
.Article{
	font-size:1.4rem;
	line-height:25px;
	padding:10px 0;
	}
.new{
	
	}
.new li{
	position:relative;
	height:28px;
	line-height:27px;
	border-bottom:#ddd 1px solid;
	padding:0 5px;
	}
.new li a{
	display:inline-block;
	width:50%;
	overflow:hidden;
	white-space:nowrap;
	text-overflow:ellipsis;          /* for IE */
	-o-text-overflow: ellipsis;      /* for Opera */
	-icab-text-overflow: ellipsis;   /* for iCab */
	-khtml-text-overflow: ellipsis;  /* for Konqueror Safari */
	-moz-text-overflow: ellipsis;    /* for Firefox,mozilla */
	-webkit-text-overflow: ellipsis; /* for Safari,Swift*/
	}
.new a:link {color: #333;} /* 未访问的链接 */
.new a:visited {color: #333;} /* 已访问的链接 */
.new a:hover{color:#333;} /* 鼠标在链接上 */ 
.new a:active {color: #333;} /* 点击激活链接——在你点击该链接之后，页面正在转向新地址的时候，链接显示此颜色；当你已经到了要链接的页面，然后再返回，原页面上的此链接仍是此颜色 */ 
.new li span{
	position:absolute;
	right:0;
	top:0;
	color:#999;
	}
</style>
